`GAPIT.MAS` <-function(Y,GD=NULL,GM=NULL,KI=NULL,GWAS=NULL,CM=NULL){
#Object: Useing MAS to predict phenotype
#Designed by Zhiwu Zhang
#Writen by Jiabo Wang
#Last update: Apr 23, 2021
##############################################################################################
print("GAPIT.MAS in process...")
#Define the function here





}

