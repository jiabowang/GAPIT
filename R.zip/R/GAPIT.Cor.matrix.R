`GAPIT.Cor.matrix`=function(a,b,...){
#Authors: Zhiwu Zhang
#Writer:  Jiabo Wang
# Last update: MAY 12, 2022 
##############################################################################################
return(cor(a,b))
}
