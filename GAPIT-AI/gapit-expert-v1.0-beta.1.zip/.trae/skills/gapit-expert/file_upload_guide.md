# 文件上传和分享指南

## 上传选项

### 选项1：GitHub Releases（推荐）
**优点**：版本管理、自动更新、访问稳定
**步骤**：
1. 创建GitHub仓库（如：gapit-expert-skill）
2. 创建Release：
   ```bash
   gh release create v1.0.0 gapit-expert-skill.zip \
     --title "GAPIT专家技能v1.0.0" \
     --notes "初始测试版本"
   ```
3. 获取下载链接：
   - `https://github.com/[用户名]/gapit-expert-skill/releases/download/v1.0.0/gapit-expert-skill.zip`

### 选项2：网盘分享
**百度网盘**：
1. 上传`gapit-expert-skill.zip`
2. 生成分享链接
3. 设置提取码（可选）
4. 有效期：建议设置永久

**Google Drive**：
1. 上传文件到Google Drive
2. 设置分享权限：知道链接的任何人可查看
3. 获取分享链接

### 选项3：自建服务器
**使用Python简单HTTP服务器**：
```bash
# 在包含文件的目录运行
python3 -m http.server 8000
```
访问：`http://[服务器IP]:8000/gapit-expert-skill.zip`

### 选项4：直接发送（小范围）
**微信文件传输**：
- 最大文件限制：通常100MB
- 建议：压缩后文件大小应小于100MB

## 文件清单

需要上传的文件：
1. `gapit-expert-skill.zip` - 主技能包
2. `install_gapit_expert.sh` - 安装脚本
3. 所有.md文档文件

## 访问链接格式

建议使用以下格式提供链接：

```
📁 文件下载：

主技能包：
https://[域名]/gapit-expert-skill.zip

安装脚本：
https://[域名]/install_gapit_expert.sh

文档查看：
https://[域名]/INSTALL.md
```

## 更新策略

1. **版本命名**：v1.0.0, v1.0.1, v1.1.0等
2. **更新通知**：在微信群中发布更新公告
3. **兼容性**：确保新版本向后兼容
4. **回滚方案**：准备旧版本下载链接

## 安全注意事项

1. **文件校验**：提供MD5或SHA256校验码
2. **访问控制**：敏感文件设置访问权限
3. **备份策略**：定期备份重要文件
4. **监控日志**：监控文件下载情况
