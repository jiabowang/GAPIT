#!/bin/bash
# GAPIT专家技能反馈处理脚本
# 版本：1.0.0
# 更新日期：2026-06-04

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 项目根目录
PROJECT_ROOT="/Users/Jiabo/Documents/trae_projects/GAPIT-Agent"
FEEDBACK_DIR="$PROJECT_ROOT/.trae/skills/gapit-expert/feedback_data"
RAW_DIR="$FEEDBACK_DIR/raw"
PROCESSED_DIR="$FEEDBACK_DIR/processed"
REPORTS_DIR="$FEEDBACK_DIR/reports"

# 创建目录结构
create_directories() {
    log_info "创建反馈数据目录结构..."
    
    mkdir -p "$RAW_DIR"
    mkdir -p "$PROCESSED_DIR"
    mkdir -p "$REPORTS_DIR"
    
    # 创建测试者子目录
    for i in {001..010}; do
        mkdir -p "$RAW_DIR/tester_$i"
    done
    
    log_success "目录结构创建完成"
}

# 处理新反馈
process_new_feedback() {
    log_info "处理新反馈..."
    
    local new_feedback_count=0
    
    # 查找新的反馈文件
    find "$RAW_DIR" -name "*.txt" -o -name "*.json" -o -name "*.md" | while read -r file; do
        local filename=$(basename "$file")
        local processed_file="$PROCESSED_DIR/$filename.processed"
        
        # 检查是否已处理
        if [ ! -f "$processed_file" ]; then
            log_info "处理新反馈: $filename"
            
            # 根据文件类型处理
            case "$filename" in
                *.json)
                    process_json_feedback "$file"
                    ;;
                *.txt)
                    process_text_feedback "$file"
                    ;;
                *.md)
                    process_markdown_feedback "$file"
                    ;;
                *)
                    log_warning "未知文件格式: $filename"
                    ;;
            esac
            
            # 标记为已处理
            touch "$processed_file"
            ((new_feedback_count++))
        fi
    done
    
    if [ $new_feedback_count -gt 0 ]; then
        log_success "处理了 $new_feedback_count 个新反馈"
    else
        log_info "没有新的反馈需要处理"
    fi
}

# 处理JSON格式反馈
process_json_feedback() {
    local file="$1"
    local feedback_id=$(basename "$file" .json)
    
    log_info "处理JSON反馈: $feedback_id"
    
    # 提取关键信息
    local tester_id=$(jq -r '.tester_id // "unknown"' "$file" 2>/dev/null || echo "unknown")
    local feedback_type=$(jq -r '.type // "general"' "$file" 2>/dev/null || echo "general")
    local content=$(jq -r '.content // ""' "$file" 2>/dev/null || echo "")
    local quality_score=$(jq -r '.quality_score // 0' "$file" 2>/dev/null || echo 0)
    
    # 保存到处理后的目录
    local processed_file="$PROCESSED_DIR/${feedback_id}_processed.json"
    
    cat > "$processed_file" << EOF
{
  "feedback_id": "$feedback_id",
  "tester_id": "$tester_id",
  "date": "$(date '+%Y-%m-%d')",
  "type": "$feedback_type",
  "content": "$(echo "$content" | sed 's/"/\\"/g')",
  "quality_score": $quality_score,
  "processing_date": "$(date '+%Y-%m-%d %H:%M:%S')",
  "status": "processed"
}
EOF
    
    log_success "JSON反馈处理完成: $processed_file"
}

# 处理文本格式反馈
process_text_feedback() {
    local file="$1"
    local feedback_id=$(basename "$file" .txt)
    
    log_info "处理文本反馈: $feedback_id"
    
    # 读取文件内容
    local content=$(cat "$file" | head -100)  # 限制前100行
    
    # 分析反馈类型
    local feedback_type="general"
    if echo "$content" | grep -qi "error\|bug\|问题"; then
        feedback_type="problem_report"
    elif echo "$content" | grep -qi "suggestion\|建议\|改进"; then
        feedback_type="improvement_suggestion"
    elif echo "$content" | grep -qi "question\|疑问\|咨询"; then
        feedback_type="question"
    fi
    
    # 保存为JSON格式
    local processed_file="$PROCESSED_DIR/${feedback_id}_processed.json"
    
    cat > "$processed_file" << EOF
{
  "feedback_id": "$feedback_id",
  "source_file": "$file",
  "date": "$(date '+%Y-%m-%d')",
  "type": "$feedback_type",
  "content_preview": "$(echo "$content" | head -5 | sed 's/"/\\"/g' | tr '\n' ' ')",
  "original_length": $(wc -l < "$file"),
  "processing_date": "$(date '+%Y-%m-%d %H:%M:%S')",
  "status": "processed"
}
EOF
    
    log_success "文本反馈处理完成: $processed_file"
}

# 处理Markdown格式反馈
process_markdown_feedback() {
    local file="$1"
    local feedback_id=$(basename "$file" .md)
    
    log_info "处理Markdown反馈: $feedback_id"
    
    # 提取标题和主要内容
    local title=$(grep -m1 "^# " "$file" | sed 's/^# //' || echo "无标题")
    local content=$(head -50 "$file")  # 前50行
    
    # 保存为JSON格式
    local processed_file="$PROCESSED_DIR/${feedback_id}_processed.json"
    
    cat > "$processed_file" << EOF
{
  "feedback_id": "$feedback_id",
  "title": "$(echo "$title" | sed 's/"/\\"/g')",
  "date": "$(date '+%Y-%m-%d')",
  "type": "detailed_feedback",
  "content_preview": "$(echo "$content" | head -3 | sed 's/"/\\"/g' | tr '\n' ' ')",
  "original_length": $(wc -l < "$file"),
  "processing_date": "$(date '+%Y-%m-%d %H:%M:%S')",
  "status": "processed"
}
EOF
    
    log_success "Markdown反馈处理完成: $processed_file"
}

# 生成反馈报告
generate_feedback_report() {
    log_info "生成反馈报告..."
    
    local report_date=$(date '+%Y-%m-%d')
    local report_file="$REPORTS_DIR/feedback_report_${report_date}.md"
    
    # 统计反馈数据
    local total_feedbacks=$(find "$PROCESSED_DIR" -name "*_processed.json" | wc -l)
    local problem_reports=$(grep -l '"type": "problem_report"' "$PROCESSED_DIR"/*.json 2>/dev/null | wc -l || echo 0)
    local suggestions=$(grep -l '"type": "improvement_suggestion"' "$PROCESSED_DIR"/*.json 2>/dev/null | wc -l || echo 0)
    
    # 计算平均质量评分
    local total_score=0
    local count=0
    
    for file in "$PROCESSED_DIR"/*_processed.json; do
        if [ -f "$file" ]; then
            local score=$(jq -r '.quality_score // 0' "$file" 2>/dev/null || echo 0)
            total_score=$(echo "$total_score + $score" | bc)
            ((count++))
        fi
    done
    
    local avg_score=0
    if [ $count -gt 0 ]; then
        avg_score=$(echo "scale=2; $total_score / $count" | bc)
    fi
    
    # 生成报告
    cat > "$report_file" << EOF
# GAPIT专家技能反馈报告
**报告日期：** $report_date
**生成时间：** $(date '+%Y-%m-%d %H:%M:%S')

## 反馈概览
| 指标 | 数量 | 说明 |
|------|------|------|
| 总反馈数 | $total_feedbacks | 所有已处理的反馈 |
| 问题报告 | $problem_reports | 功能缺陷和错误报告 |
| 改进建议 | $suggestions | 功能增强和优化建议 |
| 平均质量评分 | $avg_score/5 | 反馈质量评估 |

## 反馈分类分析

### 1. 问题类型分布
- **安装问题**：待统计
- **功能缺陷**：待统计  
- **性能问题**：待统计
- **使用体验**：待统计

### 2. 严重程度分布
- **紧急（P0）**：需要立即处理的问题
- **高（P1）**：影响主要功能的问题
- **中（P2）**：次要功能问题
- **低（P3）**：改进建议

### 3. 测试者参与情况
| 测试者ID | 反馈数量 | 活跃度 |
|----------|----------|--------|
| 待统计 | 待统计 | 待统计 |

## 重点问题摘要

### 高优先级问题（需要本周解决）
1. **问题标题**：待补充
   - **描述**：待补充
   - **影响**：待补充
   - **解决方案**：待补充

### 中优先级问题（需要本月解决）
1. **问题标题**：待补充
   - **描述**：待补充
   - **影响**：待补充
   - **解决方案**：待补充

## 改进建议汇总

### 功能增强建议
1. **建议内容**：待补充
   - **价值**：待补充
   - **实现难度**：待补充

### 用户体验优化
1. **优化点**：待补充
   - **当前问题**：待补充
   - **优化方案**：待补充

## 行动建议

### 立即行动（本周内）
1. 处理所有P0和P1优先级问题
2. 回复测试者反馈，确认问题理解正确
3. 安排问题修复时间表

### 短期行动（本月内）
1. 实施高价值改进建议
2. 优化技能性能和稳定性
3. 收集第二轮测试反馈

### 长期规划（下季度）
1. 基于反馈规划新功能
2. 扩展技能应用场景
3. 准备正式版本发布

## 附录

### 处理流程说明
1. **反馈收集**：测试者通过多种渠道提交反馈
2. **数据整理**：标准化格式，提取关键信息
3. **问题分析**：分类评估，确定优先级
4. **实施优化**：修复问题，改进功能
5. **效果评估**：监控改进效果，持续优化

### 下一步计划
1. 完善反馈分析算法
2. 建立自动化问题跟踪
3. 定期生成质量报告
4. 优化反馈处理流程

---

**报告说明**
- 本报告基于已处理的反馈数据生成
- 数据统计截止时间：$report_date 23:59:59
- 下次报告时间：$(date -v+7d '+%Y-%m-%d')

**注意事项**
- 及时处理高优先级问题
- 保持与测试者的沟通
- 定期评估改进效果
EOF
    
    log_success "反馈报告已生成：$report_file"
}

# 更新问题跟踪
update_issue_tracking() {
    log_info "更新问题跟踪..."
    
    local issue_file="$PROJECT_ROOT/.trae/skills/gapit-expert/ISSUE_TRACKING.md"
    local today=$(date '+%Y-%m-%d')
    
    if [ -f "$issue_file" ]; then
        # 在文件末尾添加新问题统计
        cat >> "$issue_file" << EOF

## 反馈统计（$today）

### 新增问题
| 问题ID | 类型 | 严重程度 | 状态 | 处理人 |
|--------|------|----------|------|--------|
| 待补充 | 待补充 | 待补充 | 待补充 | 待补充 |

### 问题趋势
- 总问题数：待统计
- 已解决：待统计
- 解决率：待统计%

### 重点关注
1. 高频问题类型：待统计
2. 影响范围大的问题：待统计
3. 用户反馈集中的功能：待统计
EOF
        
        log_success "问题跟踪已更新"
    else
        log_warning "问题跟踪文件不存在：$issue_file"
    fi
}

# 主函数
main() {
    log_info "开始处理GAPIT专家技能反馈..."
    echo ""
    
    # 1. 创建目录结构
    create_directories
    echo ""
    
    # 2. 处理新反馈
    process_new_feedback
    echo ""
    
    # 3. 生成反馈报告
    generate_feedback_report
    echo ""
    
    # 4. 更新问题跟踪
    update_issue_tracking
    echo ""
    
    log_success "反馈处理完成！"
    echo ""
    echo "📊 处理结果："
    echo "  • 反馈数据已整理到：$PROCESSED_DIR"
    echo "  • 报告已生成：$REPORTS_DIR/feedback_report_$(date '+%Y-%m-%d').md"
    echo "  • 问题跟踪已更新"
    echo ""
    echo "🎯 建议下一步："
    echo "  1. 查看反馈报告了解问题分布"
    echo "  2. 优先处理高优先级问题"
    echo "  3. 回复测试者确认问题理解"
    echo "  4. 安排问题修复计划"
}

# 执行主函数
main "$@"