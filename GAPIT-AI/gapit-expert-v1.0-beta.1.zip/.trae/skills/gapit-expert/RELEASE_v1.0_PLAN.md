# gapit-expert v1.0 训练与公开计划

本文件用于把「外部问答资料 → 训练迭代 → v1.0 发布」这条链路落到可执行的目录与产出物上。

## 目标定义（v1.0）

- 形成两套可复用的问答资料：
  - `data/gapit-resources/email-archives/`：邮件问答（优先沉淀“真实用户问题+可操作解决方案”）
  - `data/gapit-resources/user-questions/`：GitHub issues 问答（公开可追溯）
- 将高质量问答（A/B级）合并为可训练的结构化数据（JSONL/JSON）。
- 在 `SKILL.md` 与相关指南中固化“稳定规则/最佳实践/常见坑”的表达方式。
- 产出对外可发布的 `gapit-expert` skill 包（含更新说明与版本号）。

## 当前进展（本次会话已完成）

- 已创建资料落位目录：
  - `data/gapit-resources/email-archives/`
  - `data/gapit-resources/user-questions/`
- 已完成 GitHub issues 的第一轮抓取与整理（受 GitHub API 速率限制，评论可能未全量抓取）：
  - `data/gapit-resources/user-questions/github_issues_qa.jsonl`
  - `data/gapit-resources/user-questions/github_issues_qa.md`
  - `data/gapit-resources/user-questions/github_issues_unanswered.jsonl`
  - `data/gapit-resources/user-questions/github_issues_extraction_report.md`

## 邮箱数据接入（必须澄清的一点）

仅凭邮箱地址通常 **无法直接读取邮件内容**。常见可行方案：
- **方案A（推荐）**：你把相关邮件导出为 `.eml` / `.mbox` / `.txt` / `.pdf` 放到
  `data/gapit-resources/email-archives/`，我再做批量抽取与问答整理（最稳定、可复现）。
- **方案B**：开启 163 邮箱 IMAP/POP3，并提供“客户端授权码”（建议只提供授权码，不提供登录密码），我再自动抓取并筛选关键词（例如 `GAPIT|GWAS|GS|BLINK|FarmCPU|GAGBLUP|gBLUP`）。

## GitHub issues 全量化（建议）

目前可以访问 GitHub API，但若要抓取「所有 issues 的所有评论」通常需要更高的请求配额。

- 若你愿意提供一个 **只读的 GitHub Token**（临时用于本次抓取即可），即可显著提高速率并完成全量抓取。
- 如果你不方便提供 Token：我们也可以先以“issue 标题+正文”为主做初版索引，优先补齐高频问题的评论答案。

## v1.0 的迭代路线（建议顺序）

1. **数据整理**
   - GitHub：把 `github_issues_unanswered.jsonl` 中“缺答案”的条目补齐（抓评论/人工补写/基于规则总结）。
   - 邮件：导入邮件并抽取问答，按 `TRAINING_DATA_COLLECTION.md` 的 JSON 格式打标签与评分。
2. **知识固化**
   - 将反复出现的“稳定解决路径”写入 `SKILL.md`（而不是散落在案例里）。
   - 将“可复用的脚本/代码模板”收敛到固定段落与固定参数解释方式。
3. **验证与回归**
   - 用 `wechat_test_scenarios.txt` + 典型用户问题做回归问答。
   - 对 GS 部分严格遵循既定约束：全基因型+参考表型，`RefInf` 区分群体，交叉验证≥20次。
4. **打包与公开**
   - 生成 `v1.0` 变更说明（新增问答数量、覆盖范围、已知限制）。
   - 打包导出 skill，准备对外发布渠道（release / zip）。

