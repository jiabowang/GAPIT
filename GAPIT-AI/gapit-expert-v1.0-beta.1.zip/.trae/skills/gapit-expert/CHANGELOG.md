# 变更记录

## v1.0-beta.1

### 新增
- 将 `gapit-expert` 稳定为 `workspace skill` 形态，主维护副本位于 `.trae/skills/gapit-expert/`
- 新增基于真实邮件与 GitHub issues 的题库机制
- 新增题库说明：`QUESTION_BANK_GUIDE.md`
- 新增邮件学习沉淀：
  - `EMAIL_LEARNING_RULES.md`
  - `EMAIL_ITERATION_2026-07-14.md`
- 新增版本文件：`VERSION`
- 新增两类反馈目录：
  - `feedback_data/experience/`：用户使用体验反馈
  - `feedback_data/satisfaction/`：针对回答/结题结果的满意度反馈

### 数据与知识库
- 合并 34 个邮件分页压缩包，完成邮件语料构建、线程化和问答对齐
- 补抓 `jiabowang/GAPIT` GitHub issues 评论，显著降低未回答条目数
- 生成统一题库：
  - 内部题库：`data/gapit-resources/question_bank.jsonl`
  - 脱敏题库：`data/gapit-resources/question_bank_public.jsonl`

### 技能规则更新
- 新增邮件驱动的第一轮稳定规则：
  - 数值型基因型优先使用 `GD/GM`
  - HapMap 手动读入时必须核对 `header`
  - 安装或结果异常时优先重载最新 `gapit_functions.txt`
  - FarmCPU 报错优先排查重复/无变异 SNP
  - 个体数不一致优先检查样本 ID 对齐
  - `Geno.View.output=FALSE` 可作为卡顿排查开关
  - LD decay 异常需要检查函数版本
  - PVE 低值或 `NA` 需结合模型机制解释
  - BLINK/FarmCPU 不应机械追问传统单标记效应量
  - 单染色体与全基因组多位点结果差异不一定是错误

### 发布相关
- 生成带题库的发布压缩包
- 生成详细用户手册（另见用户手册文件）
- 打包修订：在压缩包内同步提供 `data/gapit-resources/code/gapit_functions.txt`，并将示例代码默认改为 `source()` 加载函数（不再推荐 `library(GAPIT)`）
