# GAPIT专家技能自动提醒设置指南

## 概述
本文档指导您如何设置自动化的每日进度跟踪和提醒系统，确保项目进度得到持续监控。

## 自动提醒方案

### 方案一：使用crontab（推荐）
crontab是Linux/macOS系统的定时任务工具，可以设置脚本在指定时间自动运行。

#### 设置步骤
1. **打开crontab编辑器**
   ```bash
   crontab -e
   ```

2. **添加每日提醒任务**
   在文件末尾添加以下行：
   ```bash
   # 每天上午9点运行进度跟踪脚本
   0 9 * * * /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh >> /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs/cron.log 2>&1
   
   # 每周五下午3点发送周报提醒
   0 15 * * 5 /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/weekly_report.sh >> /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs/weekly_cron.log 2>&1
   ```

3. **保存并退出**
   - 在vim中：按`Esc`，然后输入`:wq`
   - 在nano中：按`Ctrl+X`，然后按`Y`确认

4. **验证设置**
   ```bash
   crontab -l
   ```

#### crontab时间格式说明
```
* * * * * command_to_execute
│ │ │ │ │
│ │ │ │ └── 星期几 (0-7，0和7都表示周日)
│ │ │ └──── 月份 (1-12)
│ │ └────── 日期 (1-31)
│ └──────── 小时 (0-23)
└────────── 分钟 (0-59)
```

**常用时间示例**：
- `0 9 * * *`：每天上午9点
- `0 18 * * 1-5`：工作日晚上6点
- `0 9 * * 1`：每周一上午9点
- `0 0 1 * *`：每月1日午夜

### 方案二：使用Launchd（macOS专用）
Launchd是macOS的守护进程管理系统，功能更强大。

#### 设置步骤
1. **创建plist配置文件**
   ```bash
   sudo nano /Library/LaunchDaemons/com.gapit.expert.daily.plist
   ```

2. **添加以下内容**
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
   <plist version="1.0">
   <dict>
       <key>Label</key>
       <string>com.gapit.expert.daily</string>
       <key>ProgramArguments</key>
       <array>
           <string>/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh</string>
       </array>
       <key>StartCalendarInterval</key>
       <dict>
           <key>Hour</key>
           <integer>9</integer>
           <key>Minute</key>
           <integer>0</integer>
       </dict>
       <key>StandardOutPath</key>
       <string>/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs/launchd.log</string>
       <key>StandardErrorPath</key>
       <string>/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs/launchd_error.log</string>
   </dict>
   </plist>
   ```

3. **加载并启动服务**
   ```bash
   sudo launchctl load /Library/LaunchDaemons/com.gapit.expert.daily.plist
   sudo launchctl start com.gapit.expert.daily
   ```

### 方案三：使用Windows任务计划程序
适用于Windows用户。

#### 设置步骤
1. **打开任务计划程序**
   - 按`Win+R`，输入`taskschd.msc`，回车

2. **创建基本任务**
   - 点击"创建基本任务"
   - 名称：`GAPIT专家技能每日提醒`
   - 触发器：每天，上午9:00
   - 操作：启动程序
   - 程序/脚本：`C:\Windows\System32\bash.exe`
   - 参数：`-c "/mnt/c/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh"`

3. **完成设置**

## 提醒内容定制

### 每日提醒模板
您可以根据需要修改`daily_progress_tracker.sh`中的提醒内容：

```bash
# 修改send_reminder函数中的内容
echo "=========================================="
echo "GAPIT专家技能每日进度提醒"
echo "日期：$TODAY"
echo "=========================================="
echo ""
echo "📊 今日进度摘要："
echo "  • 测试者邀请：待发送"
echo "  • 反馈收集：0份"
echo "  • 问题跟踪：0个"
echo ""
echo "🎯 明日重点任务："
echo "  1. 发送测试邀请"
echo "  2. 建立沟通群组"
echo "  3. 准备培训材料"
echo ""
echo "⏰ 提醒：请及时跟进测试者邀请进度"
echo "=========================================="
```

### 添加邮件通知
如果您希望收到邮件提醒，可以添加以下功能：

```bash
# 在daily_progress_tracker.sh中添加邮件发送函数
send_email_reminder() {
    local subject="GAPIT专家技能每日进度报告 - $TODAY"
    local recipient="your-email@example.com"
    
    # 生成邮件内容
    local email_content=$(cat << EOF
GAPIT专家技能每日进度报告
日期：$TODAY

项目状态：
- 测试者邀请：待发送
- 反馈收集：0份
- 问题跟踪：0个

详细报告请查看附件或访问：
$DAILY_LOG_FILE

EOF
    )
    
    # 发送邮件（需要配置邮件服务器）
    echo "$email_content" | mail -s "$subject" "$recipient"
}
```

## 监控和故障排除

### 检查任务是否运行
```bash
# 检查crontab日志
tail -f /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs/cron.log

# 检查系统日志中的cron记录
grep CRON /var/log/syslog
```

### 常见问题解决

#### 问题1：脚本没有执行权限
```bash
# 解决方案：添加执行权限
chmod +x /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh
```

#### 问题2：环境变量问题
```bash
# 解决方案：在脚本开头设置环境变量
#!/bin/bash
export PATH=/usr/local/bin:/usr/bin:/bin
export HOME=/Users/Jiabo
```

#### 问题3：输出重定向失败
```bash
# 解决方案：确保日志目录存在
mkdir -p /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_logs
```

### 测试自动提醒
```bash
# 手动测试脚本
/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh

# 测试crontab语法
crontab -l

# 立即运行一次任务（测试用）
* * * * * /path/to/script.sh  # 每分钟运行一次，测试后删除
```

## 高级功能扩展

### 1. 集成Slack/微信通知
```bash
# Slack Webhook示例
send_slack_notification() {
    local message="GAPIT专家技能每日报告已生成：$DAILY_LOG_FILE"
    curl -X POST -H 'Content-type: application/json' \
    --data "{\"text\":\"$message\"}" \
    https://hooks.slack.com/services/YOUR/WEBHOOK/URL
}
```

### 2. 生成周报月报
```bash
# 创建周报脚本
cat > weekly_report.sh << 'EOF'
#!/bin/bash
# 生成周度汇总报告
# 合并过去7天的每日报告
# 计算关键指标趋势
# 发送周报提醒
EOF
```

### 3. 项目里程碑提醒
```bash
# 里程碑检查函数
check_milestones() {
    local current_date=$(date +%s)
    local milestone_date=$(date -d "2024-07-01" +%s)
    local days_remaining=$(( (milestone_date - current_date) / 86400 ))
    
    if [ $days_remaining -le 7 ]; then
        echo "⚠️  重要提醒：距离第一阶段里程碑还有 $days_remaining 天！"
    fi
}
```

## 最佳实践建议

1. **测试后再部署**：先手动运行脚本，确保正常后再设置自动任务
2. **日志监控**：定期检查日志文件，确保任务正常运行
3. **错误处理**：在脚本中添加错误处理和通知机制
4. **定期维护**：每月检查一次定时任务配置
5. **备份配置**：备份crontab或plist文件

## 安全注意事项

1. **权限控制**：不要使用root权限运行不必要的脚本
2. **敏感信息**：不要在脚本中硬编码密码或API密钥
3. **输入验证**：对脚本输入进行验证，防止注入攻击
4. **访问控制**：限制日志文件的访问权限

## 附录

### 常用命令参考
```bash
# 查看当前用户的crontab
crontab -l

# 编辑crontab
crontab -e

# 删除crontab
crontab -r

# 查看系统cron日志
tail -f /var/log/cron.log

# 查看Launchd服务状态
launchctl list | grep gapit

# 重启cron服务
sudo service cron restart
```

### 配置文件示例
完整的crontab配置示例：
```bash
# GAPIT专家技能自动提醒配置
# 更新时间：2024-06-04

# 环境变量设置
SHELL=/bin/bash
PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
MAILTO=your-email@example.com

# 每日进度跟踪（工作日9:00）
0 9 * * 1-5 /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/daily_progress_tracker.sh

# 周报生成（每周五15:00）
0 15 * * 5 /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/weekly_report.sh

# 月度数据备份（每月1日2:00）
0 2 1 * * /Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert/backup_data.sh
```

### 联系支持
如遇设置问题，请联系：
- 技术支持邮箱：gapit-support@example.com
- 紧急联系电话：[待补充]
- 微信群：[待补充群二维码]

---

**最后更新：** 2024-06-04  
**下次评审：** 2024-07-04